var searchData=
[
  ['nid',['nId',['../structplanner_1_1t_node.html#ae4b20cbcf754ea9e73e8ddc6044db0b2',1,'planner::tNode']]],
  ['nx',['nX',['../structplanner_1_1t_action.html#a6cf36892b4601d7d267d1a9d2e9d6595',1,'planner::tAction']]]
];
