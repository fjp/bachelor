var searchData=
[
  ['updatecost',['UpdateCost',['../classplanner_1_1c_planner.html#a82e45fc2701e90d3fa9df72f475e455e',1,'planner::cPlanner']]],
  ['updateheuristic',['UpdateHeuristic',['../classplanner_1_1c_planner.html#ad32a7c58b885456ced172b66fed854f0',1,'planner::cPlanner::UpdateHeuristic(tNode *i_sNode, const tHeuristic i_eHeuristic=OCTILE) const'],['../classplanner_1_1c_planner.html#a7d5f7f89a10b66f19c0257cbf7f2afbb',1,'planner::cPlanner::UpdateHeuristic(const tLocation &amp;i_sLocation, const tHeuristic i_eHeuristic=OCTILE) const']]]
];
